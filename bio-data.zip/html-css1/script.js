"use strict";

const data = ["chai", "fh", "nm", "bjuyf"];
console.log(data);
data.push("dfsghjakl");

console.log(data[0]);

const arr = new Array(1, 2, 4, 5, 3);
console.log(arr);

const arr1 = [
  { name: "chaithu", age: 24, marks: 76 },
  { name: "nam", age: 23, marks: 96 },
  { name: "cu", age: 24, marks: 6 },
];
console.log(arr1[2]);
console.log(arr1.at(1));

console.log(arr1);
data.push("kanya", "theru");
console.log(data);
data.pop();
console.log(data);
data.shift();
console.log(data);
data.unshift("myth", "kisk");
console.log(data);
